module SensuPluginsInfluxdb
  module Version
    MAJOR = 1
    MINOR = 2
    PATCH = 0

    VER_STRING = [MAJOR, MINOR, PATCH].compact.join('.')
  end
end
