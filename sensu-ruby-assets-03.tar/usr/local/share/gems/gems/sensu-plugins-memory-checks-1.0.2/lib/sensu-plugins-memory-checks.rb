require 'sensu-plugins-memory-checks/version'
