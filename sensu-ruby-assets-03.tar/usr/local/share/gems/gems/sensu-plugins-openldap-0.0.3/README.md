## Sensu-Plugins-openldap

[ ![Build Status](https://travis-ci.org/sensu-plugins/sensu-plugins-openldap.svg?branch=master)](https://travis-ci.org/sensu-plugins/sensu-plugins-openldap)
[![Gem Version](https://badge.fury.io/rb/sensu-plugins-openldap.svg)](http://badge.fury.io/rb/sensu-plugins-openldap)
[![Code Climate](https://codeclimate.com/github/sensu-plugins/sensu-plugins-openldap/badges/gpa.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-openldap)
[![Test Coverage](https://codeclimate.com/github/sensu-plugins/sensu-plugins-openldap/badges/coverage.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-openldap)
[![Dependency Status](https://gemnasium.com/sensu-plugins/sensu-plugins-openldap.svg)](https://gemnasium.com/sensu-plugins/sensu-plugins-openldap)
[ ![Codeship Status for sensu-plugins/sensu-plugins-openldap](https://codeship.com/projects/7cc16ea0-db3b-0132-9eb0-0eed4ec53b27/status?branch=master)](https://codeship.com/projects/79575)

## Functionality

## Files
 * bin/check-syncrepl.rb
 * bin/metrics-ldap.rb

## Usage

## Installation

[Installation and Setup](https://github.com/sensu-plugins/documentation/blob/master/user_docs/installation_instructions.md)

## Notes
