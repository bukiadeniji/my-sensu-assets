
require 'sensu-plugins-openldap/version'

# Load the defaults

#
# Default class
#
module SensuPluginsOpenldap
  class << self
  end

  class << self
  end
end
