# frozen_string_literal: true

require 'sensu-plugins-apache/version'
