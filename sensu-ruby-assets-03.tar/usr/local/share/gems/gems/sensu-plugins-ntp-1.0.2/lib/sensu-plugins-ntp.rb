require 'sensu-plugins-ntp/version'
