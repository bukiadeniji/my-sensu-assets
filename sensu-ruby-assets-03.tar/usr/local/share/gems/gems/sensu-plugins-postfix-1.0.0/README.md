## Sensu-Plugins-postfix

[![Build Status](https://travis-ci.org/sensu-plugins/sensu-plugins-postfix.svg?branch=master)](https://travis-ci.org/sensu-plugins/sensu-plugins-postfix)
[![Gem Version](https://badge.fury.io/rb/sensu-plugins-postfix.svg)](http://badge.fury.io/rb/sensu-plugins-postfix)
[![Code Climate](https://codeclimate.com/github/sensu-plugins/sensu-plugins-postfix/badges/gpa.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-postfix)
[![Test Coverage](https://codeclimate.com/github/sensu-plugins/sensu-plugins-postfix/badges/coverage.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-postfix)
[![Dependency Status](https://gemnasium.com/sensu-plugins/sensu-plugins-postfix.svg)](https://gemnasium.com/sensu-plugins/sensu-plugins-postfix)

## Functionality

## Files
 * bin/check-mailq.rb
 * bin/check-mail-delay.rb
 * bin/metrics-mailq.rb

## Usage

## Installation

[Installation and Setup](http://sensu-plugins.io/docs/installation_instructions.html)

## Notes
