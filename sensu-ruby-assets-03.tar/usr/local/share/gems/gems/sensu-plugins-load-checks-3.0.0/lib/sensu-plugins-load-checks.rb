require 'sensu-plugins-load-checks/version'
