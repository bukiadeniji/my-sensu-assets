require 'sensu-plugins-ssl/version'
