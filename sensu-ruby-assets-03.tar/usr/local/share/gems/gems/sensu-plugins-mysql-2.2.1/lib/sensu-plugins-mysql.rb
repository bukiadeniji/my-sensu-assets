require 'sensu-plugins-mysql/version'
