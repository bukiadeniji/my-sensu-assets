# Change Log
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

## [0.1.0] - 2017-08-31
### Added
- Add support to capture more PowerDNS metrics like queries/second (@haashah)

## 0.0.1 - 2017-08-27
### Added
- Initial release

[Unreleased]: https://github.com/sensu-plugins/sensu-plugins-pdns/compare/0.0.1...HEAD
[0.1.0]: https://github.com/sensu-plugins/sensu-plugins-pdns/compare/0.0.1...0.1.0
