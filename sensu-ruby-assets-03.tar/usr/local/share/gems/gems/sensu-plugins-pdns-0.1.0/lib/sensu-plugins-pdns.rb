require 'sensu-plugins-pdns/version'
