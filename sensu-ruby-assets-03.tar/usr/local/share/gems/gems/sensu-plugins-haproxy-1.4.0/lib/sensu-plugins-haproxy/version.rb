module SensuPluginsHAProxy
  module Version
    MAJOR = 1
    MINOR = 4
    PATCH = 0

    VER_STRING = [MAJOR, MINOR, PATCH].compact.join('.')
  end
end
