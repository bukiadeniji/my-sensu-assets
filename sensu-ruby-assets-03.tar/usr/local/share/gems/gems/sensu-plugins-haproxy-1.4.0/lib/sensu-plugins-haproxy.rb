require 'sensu-plugins-haproxy/version'
