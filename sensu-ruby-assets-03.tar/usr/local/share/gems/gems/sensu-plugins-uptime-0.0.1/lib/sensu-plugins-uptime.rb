require 'sensu-plugins-uptime/version'
