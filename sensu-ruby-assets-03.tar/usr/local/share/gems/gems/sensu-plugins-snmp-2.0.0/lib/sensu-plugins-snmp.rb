require 'sensu-plugins-snmp/version'
