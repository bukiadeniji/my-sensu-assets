module SensuPluginsDiskChecks
  module Version
    MAJOR = 2
    MINOR = 5
    PATCH = 1

    VER_STRING = [MAJOR, MINOR, PATCH].compact.join('.')
  end
end
