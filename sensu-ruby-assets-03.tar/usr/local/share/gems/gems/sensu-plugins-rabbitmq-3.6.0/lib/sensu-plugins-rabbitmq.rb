require 'ruby_dig'

require 'sensu-plugins-rabbitmq/version'
require 'sensu-plugins-rabbitmq/check'
require 'sensu-plugins-rabbitmq/metrics'
