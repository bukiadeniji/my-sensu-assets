require 'sensu-plugins-cpu-checks/version'
