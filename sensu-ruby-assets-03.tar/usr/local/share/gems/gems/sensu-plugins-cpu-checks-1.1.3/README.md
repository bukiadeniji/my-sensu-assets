## Sensu-Plugins-cpu-checks

[ ![Build Status](https://travis-ci.org/sensu-plugins/sensu-plugins-cpu-checks.svg?branch=master)](https://travis-ci.org/sensu-plugins/sensu-plugins-cpu-checks)
[![Gem Version](https://badge.fury.io/rb/sensu-plugins-cpu-checks.svg)](http://badge.fury.io/rb/sensu-plugins-cpu-checks)
[![Code Climate](https://codeclimate.com/github/sensu-plugins/sensu-plugins-cpu-checks/badges/gpa.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-cpu-checks)
[![Test Coverage](https://codeclimate.com/github/sensu-plugins/sensu-plugins-cpu-checks/badges/coverage.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-cpu-checks)
[![Dependency Status](https://gemnasium.com/sensu-plugins/sensu-plugins-cpu-checks.svg)](https://gemnasium.com/sensu-plugins/sensu-plugins-cpu-checks)

## Functionality

## Files
 * bin/check-cpu.rb
 * bin/check-cpu.sh
 * bin/metrics-cpu-mpstat.rb
 * bin/metrics-cpu-pcnt-usage.rb
 * bin/metrics-numastat.rb
 * bin/metrics-user-pct-usage.rb

## Usage

## Installation

[Installation and Setup](http://sensu-plugins.io/docs/installation_instructions.html)

## Notes
