require 'sensu-plugins-http/version'
require 'sensu-plugins-http/common'
