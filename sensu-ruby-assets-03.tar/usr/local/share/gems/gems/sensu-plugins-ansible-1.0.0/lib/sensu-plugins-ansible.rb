# frozen_string_literal: true

require 'sensu-plugins-ansible/version'
