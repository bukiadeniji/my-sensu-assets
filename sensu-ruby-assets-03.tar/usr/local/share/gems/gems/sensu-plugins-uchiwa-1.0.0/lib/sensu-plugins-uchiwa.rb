
require 'sensu-plugins-uchiwa/version'

# Load the defaults

#
# Default class
#
module SensuPluginsUchiwa
  class << self
  end

  class << self
  end
end
