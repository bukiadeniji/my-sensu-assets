require 'sensu-plugins-dns/version'
