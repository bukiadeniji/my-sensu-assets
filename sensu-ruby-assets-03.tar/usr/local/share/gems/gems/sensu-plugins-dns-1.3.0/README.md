## Sensu-Plugins-dns

[![Build Status](https://travis-ci.org/sensu-plugins/sensu-plugins-dns.svg?branch=master)](https://travis-ci.org/sensu-plugins/sensu-plugins-dns)
[![Gem Version](https://badge.fury.io/rb/sensu-plugins-dns.svg)](http://badge.fury.io/rb/sensu-plugins-dns)
[![Code Climate](https://codeclimate.com/github/sensu-plugins/sensu-plugins-dns/badges/gpa.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-dns)
[![Test Coverage](https://codeclimate.com/github/sensu-plugins/sensu-plugins-dns/badges/coverage.svg)](https://codeclimate.com/github/sensu-plugins/sensu-plugins-dns)
[![Dependency Status](https://gemnasium.com/sensu-plugins/sensu-plugins-dns.svg)](https://gemnasium.com/sensu-plugins/sensu-plugins-dns)

## Functionality

## Files
 * bin/check-dns.rb
 * bin/metrics-dns.rb

## Usage

## Installation

[Installation and Setup](http://sensu-plugins.io/docs/installation_instructions.html)

## Notes

