require 'sensu-plugins-nginx/version'
