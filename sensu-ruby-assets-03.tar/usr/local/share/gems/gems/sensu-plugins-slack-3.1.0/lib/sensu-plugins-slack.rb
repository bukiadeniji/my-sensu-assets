require 'sensu-plugins-slack/version'
