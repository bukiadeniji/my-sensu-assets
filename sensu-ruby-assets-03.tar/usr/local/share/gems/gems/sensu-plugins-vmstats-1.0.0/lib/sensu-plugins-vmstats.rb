require 'sensu-plugins-vmstats/version'
