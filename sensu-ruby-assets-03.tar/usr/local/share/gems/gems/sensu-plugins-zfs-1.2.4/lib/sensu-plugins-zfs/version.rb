module SensuPluginsZFS
  VERSION = "1.2.4"
end
