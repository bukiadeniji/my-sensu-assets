require 'sensu-plugins-mailer/version'
