module SensuPluginsRedis
  module Version
    MAJOR = 2
    MINOR = 3
    PATCH = 2

    VER_STRING = [MAJOR, MINOR, PATCH].compact.join('.')
  end
end
