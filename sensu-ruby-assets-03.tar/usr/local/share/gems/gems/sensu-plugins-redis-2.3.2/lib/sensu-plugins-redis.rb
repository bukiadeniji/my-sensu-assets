require 'sensu-plugins-redis/version'
